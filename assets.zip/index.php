<?php
$page_title ="O&k Builders | A Constructive Solution To Your Building Designs.";
require_once('views/layouts/header.php');

require_once('views/index-content.php');

require_once('views/layouts/footer.php');
?>